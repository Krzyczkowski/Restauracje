create function test() returns trigger
    language plpgsql
as
$$
BEGIN
		 
         
		 IF (TG_OP = 'DELETE') THEN
            INSERT INTO logi (tabela,uzytkownik,data,operacja)
         VALUES('a',user,current_date,'delete');
        ELSIF (TG_OP = 'UPDATE') THEN
            INSERT INTO logi (tabela,uzytkownik,data,operacja)
         VALUES('a',user,current_date,'update');
        ELSIF (TG_OP = 'INSERT') THEN
            INSERT INTO logi (tabela,uzytkownik,data,operacja)
         	VALUES('a',user,current_date,'insert');
		END IF;
		 
 
    RETURN NEW;
END;
$$;

alter function test() owner to postgres;

